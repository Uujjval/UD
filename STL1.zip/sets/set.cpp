// Online C++ compiler to run C++ program online
#include <iostream>
#include <set>
using namespace std;

int main() {
    // Write C++ code here
    
    set<int> s;
    
    for(int i=0;i<3;i++)
    {
        int x;
        
        cout<<"enter value: ";
        cin>>x;
        
        s.insert(x);
    }
    
    set<int> :: iterator it;
    
    for(it=s.begin();it!=s.end();it++)
    {
        cout<<*it<<endl;
    }

    return 0;
}