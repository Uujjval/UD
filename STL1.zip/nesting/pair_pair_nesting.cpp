#include <iostream>
using namespace std;

int main()
{
    pair<pair<int,int>, pair<int,int>> np;
    
    np = make_pair(make_pair(2,6),make_pair(9,3));
    
    cout<<"First Pair : "<<np.first.first<<" "<<np.first.second<<endl;
    cout<<"Second Pair : "<<np.second.first<<" "<<np.second.second<<endl;

    return 0;
}


// #include <iostream>
// using namespace std;

// int main()
// {
//     pair<pair<int,int>, pair<int,int>> np[2];
    
//     for(int i=0;i<2;i++)
//     {
//         cout<<"first pair first element : ";
//         cin>>np[i].first.first;
        
//         cout<<"first pair second element : ";
//         cin>>np[i].first.second;
        
//         cout<<"second pair first element : ";
//         cin>>np[i].second.first;
        
//         cout<<"second pair second element : ";
//         cin>>np[i].second.second;
//     }
    
//     for(int i=0;i<2;i++)
//     {
//         cout<<"First Pair : "<<np[i].first.first<<" "<<np[i].first.second;
//         cout<<" Second Pair : "<<np[i].second.first<<" "<<np[i].second.second<<endl;
//     }
    

//     return 0;
// }