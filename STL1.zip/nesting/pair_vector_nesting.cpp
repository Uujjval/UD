#include<iostream>
#include<vector>
using namespace std;

int main()
{
    pair<vector<int>,vector<int>> pv;
    
    int n;
    
    cout<<"enter pair size : ";
    cin>>n;
    
    pv.first.resize(n);
    pv.second.resize(n);
    
    for(int i=0;i<n;i++)
    {
        int x;
        
        cout<<"enter first value for first vector : ";
        cin>>x;
        
        pv.first[i]=x;
    }
    
    for(int i=0;i<n;i++)
    {
        int x;
        
        cout<<"enter first value for second vector : ";
        cin>>x;
        
        pv.second[i]=x;
    }
    
    for(int i=0;i<n;i++)
    {
        cout<<pv.first[i]<<" ";
    }
    
    cout<<endl;
    
    for(int i=0;i<n;i++)
    {
        cout<<pv.second[i]<<" ";
    }
}