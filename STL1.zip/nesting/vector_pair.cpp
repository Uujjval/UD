#include<iostream>
#include<vector>
using namespace std;

int main()
{
    vector<pair<int,int>> v;
    
    int n;
    
    cout<<"enter vector size : ";
    cin>>n;
    
    for(int i=0;i<n;i++)
    {
        int fe,se;
        
        cout<<"enter first element : ";
        cin>>fe;
        
        cout<<"enter second element : ";
        cin>>se;
        
        v.push_back(make_pair(fe,se));
    }
    
    for(int i=0;i<n;i++)
    {
        cout<<v[i].first<<" "<<v[i].second<<endl;
    }
    
    return 0;
}